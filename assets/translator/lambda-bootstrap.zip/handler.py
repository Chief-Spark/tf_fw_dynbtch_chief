def lambda_handler(event, context):
    raise RuntimeError("Bootstrap placeholder: deploy code via tf_trnsltr_btch")

def handler(event, context):
    return lambda_handler(event, context)